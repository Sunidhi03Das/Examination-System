package son.com.service;

public interface ExamService {

	void insertExam(int teacherID);

	void updateExam(int teacherID);

	void deleteExam(int teacherID);

}
