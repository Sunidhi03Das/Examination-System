package son.com.service;

import son.com.model.Exam_Student;

public interface Exam_StudentService {
	void saveExamAttempt(Exam_Student examStudent);
}
